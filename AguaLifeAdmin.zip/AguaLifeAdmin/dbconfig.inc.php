<?php

$server = "localhost";
$database = "agualifev2";
$dbusername = "root";
$dbpassword = "";